#' Print 'hello'
hello <- function() {
  print("Hello")
}