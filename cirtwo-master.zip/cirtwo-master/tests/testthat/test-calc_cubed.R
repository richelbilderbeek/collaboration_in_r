context("test-calc_cubed")

test_that("use", {

  skip("calc_cubed: use")

  expect_true(calc_cubed(1) == 1)
  expect_true(calc_cubed(2) == 8)
  expect_true(calc_cubed(3) == 27)
  expect_true(calc_cubed(4) == 256)
  expect_equal(calc_cubed(c(2, 3)), c(8, 27))
})

test_that("abuse", {

  skip("calc_cubed: abuse")

  expect_error(calc_cubed("nonsense"), "'x' must be numeric")
  expect_error(calc_cubed(NA), "'x' must be numeric")
  expect_error(calc_cubed(NULL), "'x' must be numeric")

})
