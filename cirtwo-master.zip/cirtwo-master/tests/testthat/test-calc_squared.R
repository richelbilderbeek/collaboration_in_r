context("test-calc_squared")

test_that("use", {

  skip("calc_squared: use")
  expect_true(calc_squared(1) == 1)
  expect_true(calc_squared(2) == 4)
  expect_true(calc_squared(3) == 9)
  expect_true(calc_squared(4) == 16)
  expect_equal(calc_squared(c(2, 3)), c(4, 9))
})

test_that("abuse", {

  skip("calc_squared: abuse")
  expect_error(calc_squared("nonsense"), "'x' must be numeric")
  expect_error(calc_squared(NA), "'x' must be numeric")
  expect_error(calc_squared(NULL), "'x' must be numeric")
})
