context("test-get_crown_age")

test_that("use", {

  skip("get_crown_age: use")
  phylogeny <- ape::read.tree(text = "((A:1, B:1):1, C:2);")
  crown_age <- get_crown_age(phylogeny = phylogeny)
  expect_equal(created, 2)

  phylogeny <- ape::read.tree(text = "((A:2, B:2):1, C:3);")
  crown_age <- get_crown_age(phylogeny = phylogeny)
  expect_equal(created, 3)
})

test_that("abuse", {

  skip("get_crown_age: abuse")

  expect_error(get_crown_age("?"), "'phylogeny' must be of class 'phylo'")
  expect_error(get_crown_age(NA), "'phylogeny' must be of class 'phylo'")
  expect_error(get_crown_age(NULL), "'phylogeny' must be of class 'phylo'")

})
