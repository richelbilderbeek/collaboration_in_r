library(testthat)
library(cirtwo)

test_check("cirtwo")
